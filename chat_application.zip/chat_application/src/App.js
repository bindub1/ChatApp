import React from "react";
import { ChatEngine } from "react-chat-engine";
import LoginForm from "./components/LoginForm";
import ChatFeed from "./components/ChatFeed";
import Logout from "./components/Logout";
import "./App.css";

const App = () => {
  if (!localStorage.getItem("userName")) return <LoginForm />;

  const isLoggedIn = localStorage.getItem("userName");
  return (
    <div>
      <div>{isLoggedIn && <Logout />}</div>
      <ChatEngine
        height="90vh"
        projectID="48363f54-c782-4d72-b321-233d20cdc066"
        // userName="kamala"
        userName={localStorage.getItem("userName")}
        userSecret={localStorage.getItem("password")}
        renderChatFeed={(chatAppProps) => <ChatFeed {...chatAppProps} />}
      />
    </div>
  );
};

export default App;
