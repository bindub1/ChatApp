import React, { useState } from 'react'
import axios from 'axios';
import Logo from './../assets/logo.svg'
const LoginForm = () => {
    const [userName, setUserName] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const handleSubmit = async (e) => {
        e.preventDefault()
        const authObject = { 'Project-ID': '48363f54-c782-4d72-b321-233d20cdc066', 'User-Name': userName, 'User-Secret': password };
        try {
            await axios.get('https://api.chatengine.io/chats', { headers: authObject })
            localStorage.setItem('userName', userName)
            localStorage.setItem('password', password)
            window.location.reload()
        } catch (error) {
            setError('Opps! Incorrect Credentails')
        }

    }
    return (
        <div className="wrapper">
            <div className="form">
                <h1 className="title">Web Chat VSA</h1>
                <img src={Logo} className="logo-animation" />
                <form onSubmit={handleSubmit} >
                    <input type="text" onChange={(e) => setUserName(e.target.value)} value={userName} className="input" required placeholder="Username" />
                    <input type="password" onChange={(e) => setPassword(e.target.value)} value={password} className="input" required placeholder="Password" />
                    <div align="center">
                        <button type="submit" className="button">
                            <span>Start Chatting</span>
                        </button>
                    </div>
                    <h1 className="error">{error}</h1>
                </form>

            </div>
        </div >
    )
}

export default LoginForm;
