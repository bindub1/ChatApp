import MessageForm from "./MessageForm";
import IncomingMessage from "./IncomingMessage";
import OutgoingMessage from "./OutgoingMessage";
const ChatFeed = (chatProps) => {
  const { chats, activeChat, userName, messages } = chatProps;

  const chat = chats && chats[activeChat];

  const renderReadReciepts = (message, isMyMessage) => {
    return chat.people.map((person, i) => person.last_read === message.id && (
      <div
        key={`read_${i}`}
        className="read-receipt"
        style={{
          float: isMyMessage ? 'right' : 'left',
          backgroundImage: `url(${person?.person?.avatar})`
        }}
      />
    ));
  }

  const renderMessages = () => {
    const keys = Object.keys(messages);
    return keys.map((key, index) => {
      const message = messages[key];
      const lastMessageKey = index === 0 ? null : keys[index - 1];
      const isMyMessage = userName === message.sender.username;

      return (
        <div key={`msg_${index}`} style={{ width: '100%' }}>
          <div className="message-block">
            {
              isMyMessage ? <OutgoingMessage message={message} /> : <IncomingMessage message={message} lastMessage={messages[lastMessageKey]} />
            }
          </div>
          <div className="read-reciepts" style={{ marginRight: isMyMessage ? '18px' : '0px', marginLeft: isMyMessage ? '0px' : '8%' }}>
            {renderReadReciepts(message, isMyMessage)}
          </div>
        </div>
      )
    })
  }

  if (!chat) return <div />;

  return (
    <div className="chat-feed">
      <div className="chat-title-container">
        <div className="chat-title">{chat?.title}</div>
        <div className="chat-subtitle">
          {chat.people.map((person) => `${person.person.username}`)}
        </div>
      </div>
      {renderMessages()}
      <div style={{ height: '40px' }} />
      <div className="message=form-container">
        <MessageForm {...chatProps} chatId={activeChat} />
      </div>
    </div>
  )
};

export default ChatFeed;
