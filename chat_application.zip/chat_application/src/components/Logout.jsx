import React from 'react'

const Logout = () => {

    const handleClick = () => {
        localStorage.clear();
        window.location.reload()
    }
    return (
        <div style={{ height: '9vh', backgroundColor: '#CABCDC' }}>
            <button className="button-logout" onClick={handleClick}>Logout</button>
        </div>
    );
}

export default Logout;
